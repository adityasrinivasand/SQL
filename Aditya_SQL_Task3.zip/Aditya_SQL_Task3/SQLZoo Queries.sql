/**** Medium ****/ 

/***6) A "Single Item Order" is a customer order where only one item is ordered. Show the SalesOrderID and the UnitPrice for every Single Item Order.
	***/

	Select SalesOrderID, UnitPrice from SalesOrderDetail Where OrderQty = 1;

/***7) Where did the racing socks go? List the product name and the CompanyName for all Customers who ordered ProductModel 'Racing Socks'. ***/

Select P.Name , C.CompanyName 
FROM Customer C
inner join SalesOrderHeader soh on C.CustomerID = soh .CustomerID 
inner join SalesOrderDetail sod on soh.SalesOrderID = sod.SalesOrderID 
inner join Product P on sod .ProductID = P.ProductID 
inner join ProductModel PM on P.ProductModelID = PM.ProductModelID   
WHERE PM.name='Racing Socks';

/***8) Show the product description for culture 'fr' for product with ProductID 736.***/

Select pd.Description FROM ProductDescription pd 
inner join ProductModelProductDescription pmpd on pd.ProductDescriptionID = pmpd.ProductDescriptionID 
inner join ProductModel PM on pmpd .ProductModelID = PM.ProductModelID 
inner join Product P on P.ProductModelID = PM.ProductModelID  
WHERE P.ProductID = 736 AND pmpd.Culture = 'fr'

/*** 10) How many products in ProductCategory 'Cranksets' have been sold to an address in 'London'? ***/

Select Count(*) From ProductCategory pc
inner join Product P on pc.ProductCategoryID= P .ProductCategoryID 
inner join SalesOrderDetail sod on sod .ProductID = P.ProductID 
inner join SalesOrderHeader soh on soh .SalesOrderID = sod .SalesOrderID 
inner join Customer C on soh .CustomerID = C.CustomerID 
inner join CustomerAddress CA on CA .CustomerID = C.CustomerID  
inner join Address A on CA.AddressID = A.AddressID
WHERE City = 'London' AND pc.Name = 'Cranksets'

/**** Hard ***/ 
/*** 11) For every customer with a 'Main Office' in Dallas show AddressLine1 of the 'Main Office' and AddressLine1 of the 'Shipping' address - if there is no shipping address leave it blank. Use one row per customer.
 ***/

SELECT C.CompanyName,
  MAX(CASE WHEN AddressType = 'Main Office' THEN AddressLine1 ELSE '' END) AS 'Main Office Address',
  MAX(CASE WHEN AddressType = 'Shipping' THEN AddressLine1 ELSE '' END) AS 'Shipping Address'
FROM Customer C
join CustomerAddress CA ON C.CustomerID = CA.CustomerID
join  Address A ON CA.AddressID = A.AddressID
WHERE A.City = 'Dallas'
GROUP BY C.CompanyName;

/*** 12) For each order show the SalesOrderID and SubTotal calculated three ways:
A) From the SalesOrderHeader
B) Sum of OrderQty*UnitPrice
C) Sum of OrderQty*ListPrice ***/

SELECT soh.SalesOrderID,
  soh.SubTotal,
  SUM(sod.OrderQty * sod.UnitPrice),
  SUM(sod.OrderQty * p.ListPrice)
FROM SalesOrderHeader soh
join  SalesOrderDetail sod ON soh.SalesOrderID = sod.SalesOrderID
join  Product p ON sod.ProductID = p.ProductID
GROUP BY soh.SalesOrderID,soh.SubTotal;

/*** 13)Show the best selling item by value. ***/

SELECT P.Name,
  SUM(Sod.OrderQty * Sod.UnitPrice) AS TotalValue
FROM Product P
join  SalesOrderDetail sod ON P.ProductID = sod.ProductID
GROUP BY P.Name
ORDER BY TotalValue DESC